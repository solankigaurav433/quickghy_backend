package com.quickghy.backend.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="services_quickghy")
public class QuickghyServicesModel {
	
	@Id
	private String id;
	
	private String name;
	private String provider;
	private String caption;
	
	public QuickghyServicesModel() {
		
	}
	public QuickghyServicesModel(String id,String name, String provider, String caption) {
		this.id=id;
		this.name=name;
		this.provider=provider;
		this.caption=caption;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	
	
	
}
