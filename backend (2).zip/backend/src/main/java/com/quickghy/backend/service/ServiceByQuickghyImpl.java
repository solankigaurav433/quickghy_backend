package com.quickghy.backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quickghy.backend.model.QuickghyServicesModel;
import com.quickghy.backend.repository.ServicesRepo;

@Service
public class ServiceByQuickghyImpl implements ServiceByQuickghy {

	@Autowired
	private ServicesRepo repo;

	@Override
	public List<QuickghyServicesModel> getAll() {

		return repo.findAll();
	}

	@Override
	public QuickghyServicesModel findByServicename(String name) {

		return repo.findByName(name);
	}

	@Override
	public QuickghyServicesModel saveService(QuickghyServicesModel quickghyServices) {

		return repo.save(quickghyServices);
	}

	@Override
	public void deleteServicesById(String id) {
		repo.deleteById(id);

	}

	@Override
	public Optional<QuickghyServicesModel> findByServiceId(String id) {

		return repo.findById(id);
	}

	@Override
	public QuickghyServicesModel updateService(QuickghyServicesModel quickghyServices) {

		return repo.save(quickghyServices);
	}

}
