package com.quickghy.backend.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.quickghy.backend.model.Users;

@Repository
public interface UserRepo extends MongoRepository<Users, String> {

	public Users findByUsername(String username);
}
