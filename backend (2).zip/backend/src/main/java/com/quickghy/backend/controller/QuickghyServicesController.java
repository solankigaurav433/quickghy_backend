package com.quickghy.backend.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quickghy.backend.model.QuickghyServicesModel;
import com.quickghy.backend.service.ServiceByQuickghy;

@RestController
@RequestMapping("/services")
public class QuickghyServicesController {
	
	@Autowired
	private ServiceByQuickghy service;
	
	@GetMapping(value="/")
	public List<QuickghyServicesModel> getAllServices(){
		return service.getAll();
	}
	
	@GetMapping(value="/byServicesId/{id}")
	public Optional<QuickghyServicesModel> getServicesById(@PathVariable("id") String id) {
		return service.findByServiceId(id);
		
	}
	
	@GetMapping(value="/byServicesName/{name}")
	public QuickghyServicesModel getServicesByName(@PathVariable("name") String name) {
		return service.findByServicename(name);
		
	}
	
	@PostMapping(value="/save")
	public QuickghyServicesModel quickghyServices(@RequestBody QuickghyServicesModel quickghyServices) {
		return service.saveService(quickghyServices);
	}
	
	@PutMapping(value="/update/{id}")
	public QuickghyServicesModel quickghyServices(@RequestBody QuickghyServicesModel quickghyServices, @PathVariable String id){
		Optional<QuickghyServicesModel> oldServices = service.findByServiceId(id);
		if(oldServices.isPresent()) {
			QuickghyServicesModel obj = oldServices.get();
			obj.setName(quickghyServices.getName());
			obj.setProvider(quickghyServices.getProvider());
			obj.setCaption(quickghyServices.getCaption());
			return service.saveService(obj);
		}else {
			return null;
		}
	}
	
	@DeleteMapping(value="/delete/{id}")
	public void deleteServicesById(@PathVariable String id) {
		 service.deleteServicesById(id);
	}
	
	
	
	
}
