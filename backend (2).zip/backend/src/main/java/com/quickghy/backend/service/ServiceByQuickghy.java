package com.quickghy.backend.service;

import java.util.List;
import java.util.Optional;

import com.quickghy.backend.model.QuickghyServicesModel;

public interface ServiceByQuickghy {
	
	public List<QuickghyServicesModel> getAll();
	
	public Optional<QuickghyServicesModel> findByServiceId(String id);
	
	public QuickghyServicesModel findByServicename(String name);
	
	public QuickghyServicesModel saveService(QuickghyServicesModel quickghyServices);
	
	public QuickghyServicesModel updateService(QuickghyServicesModel quickghyServices);
	
	void deleteServicesById(String id);
}
