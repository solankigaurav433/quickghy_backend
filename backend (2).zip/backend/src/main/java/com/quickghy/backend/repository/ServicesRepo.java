package com.quickghy.backend.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.quickghy.backend.model.QuickghyServicesModel;

@Repository
public interface ServicesRepo extends MongoRepository<QuickghyServicesModel, String>
{
	
	public QuickghyServicesModel findByName (String name);
	
}
