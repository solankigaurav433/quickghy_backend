package com.quickghy.backend.service;

import java.util.List;
import java.util.Optional;

import com.quickghy.backend.model.Users;

public interface UserService {
	public Users addUser(Users user);
	public Optional<Users> findUserById(String id);
	public List<Users> getAllUser();
	public Users getUserById(String id);
	public Users findUserByName(String username);
}
