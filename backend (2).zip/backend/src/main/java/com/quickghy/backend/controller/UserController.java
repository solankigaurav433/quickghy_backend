package com.quickghy.backend.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quickghy.backend.model.Users;
import com.quickghy.backend.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private BCryptPasswordEncoder bcrypt;

	@PostMapping("/register")
	public Users addUsers(@RequestBody Users user) {
		user.setPassword(bcrypt.encode(user.getPassword()));
		return service.addUser(user);
	}

	@GetMapping("/AllUser")
	public List<Users> getAllUser() {
		return service.getAllUser();
	}

	@GetMapping("/{id}")
	public Optional<Users> findUserById(@PathVariable String id) {
		return service.findUserById(id);
	}

//	profile
	@GetMapping("/Detail/{username}")
	public Users findUserByName(@PathVariable String username) {
		System.out.println("In User Detail " + username);
		return service.findUserByName(username);
	}

	@PutMapping("/profileUpdate/{id}")
	public Users updateUsers(@RequestBody Users user, @PathVariable String id) {
		Optional<Users> oldUser = service.findUserById(id);
		if (oldUser.isPresent()) {
			Users obj = oldUser.get();
			obj.setName(user.getName());
			obj.setEmail(user.getEmail());
			obj.setUsername(user.getUsername());
			return service.addUser(obj);
		} else {
			return null;
		}
	}

}