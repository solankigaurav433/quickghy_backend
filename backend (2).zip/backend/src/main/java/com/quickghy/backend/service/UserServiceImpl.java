package com.quickghy.backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.quickghy.backend.model.Users;
import com.quickghy.backend.repository.UserRepo;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepo repo;

	@Override
	public Users addUser(Users user) {

		return repo.save(user);
	}

	@Override
	public Optional<Users> findUserById(String id) {

		return repo.findById(id);
	}
	
	@Override
	public Users findUserByName(String username) {

		return repo.findByUsername(username);
	}
	
	@Override
	public Users getUserById(String id) {
		Users user = null;
		Optional<Users> oldUser = repo.findById(id);
		if (oldUser.isPresent()) {
			user = oldUser.get();
		}
		return user;
	}

	@Override
	public List<Users> getAllUser() {

		return repo.findAll();
	}

}
